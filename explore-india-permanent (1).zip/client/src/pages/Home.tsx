import { useEffect } from "react";

/**
 * Explore India - Premium Travel Website
 * This page serves the static website with integrated chatbot
 */
export default function Home() {
  useEffect(() => {
    // Redirect to the static website
    window.location.href = "/index.html";
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-orange-50 to-blue-50">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          🌏 Explore India
        </h1>
        <p className="text-lg text-gray-600 mb-8">
          Premium Travel Website with AI Chatbot
        </p>
        <div className="animate-spin">
          <div className="w-12 h-12 border-4 border-orange-200 border-t-orange-600 rounded-full mx-auto"></div>
        </div>
        <p className="text-sm text-gray-500 mt-8">Loading your travel experience...</p>
      </div>
    </div>
  );
}
